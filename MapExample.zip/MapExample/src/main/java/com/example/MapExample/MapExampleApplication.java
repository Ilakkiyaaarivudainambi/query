package com.example.MapExample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages=("com.example.MapExample"))
public class MapExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(MapExampleApplication.class, args);
	}

}
