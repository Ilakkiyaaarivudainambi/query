package com.example.MapExample.Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.MapExample.Map_Service;



@RestController
@RequestMapping("/api/")
public class Map_Controller {
	
	@Autowired Map_Service obj;

	@Value("${filelink}")
	private String vari;
	@RequestMapping(value = "testAPI", method = RequestMethod.GET)
	
	public ResponseEntity<?> testApi(@RequestParam Map<String, String> mapex)throws Exception {
		System.out.println("input is:"+mapex);
		int ans = 0;
		String status="";
		try {
		status="success";
		String s=mapex.get("op").toString();
		
		int a=Integer.parseInt(mapex.get("n1").toString());
		int b=Integer.parseInt(mapex.get("n2").toString());
		switch (s) {
		case "add":
			ans = obj.add(a, b);
			break;
		case "sub":
			ans = obj.sub(a, b);
			break;
		case "multiply":
			ans = obj.multiplication(a, b);
			break;
		case "division":

			ans = obj.division(a, b);
			break;
			}
		mapex.put("status","success");
		}
		catch(Exception e) {
			//status="fail";
			mapex.put("status",e.getMessage());
		//	System.out.println("output is :"+e);
		}
		mapex.put("ans", Integer.toString(ans));
		return new ResponseEntity<>(mapex, HttpStatus.OK);
	}
	@RequestMapping(value = "load", method = RequestMethod.GET)
	public ResponseEntity<?> loadProperty(@RequestParam Map<String, String> requestParam) throws Exception {

		Properties prop = new Properties();

		prop.put("Id", "101");
		prop.put("Name", "ilakkiyaa");
		prop.put("Designation", "Software Developer");

		FileOutputStream out = new FileOutputStream("D:\\FileOperations\\joyDetails.properties");
		prop.store(out, "Details");

		try {
		// File f = new File("D:\\FileOperations\\propFile.properties");
		FileInputStream fin = new FileInputStream(vari);
		prop.load(fin);

		} catch (Exception e) {
		System.out.println((e));
		}

		return new ResponseEntity<>(prop , HttpStatus.OK);
		}
	
//	@RequestMapping(value = "load", method = RequestMethod.GET)	
//	public ResponseEntity<?> loadProperty(@RequestParam Map<String, String> mapex)throws Exception {
//		//System.out.println("input is:"+mapex); 
//		Properties prop=new Properties();
//		try {
//		FileInputStream f=new FileInputStream("‪C:\\New\\props.properties");
//		
//		prop.load(f);
//		}
//		catch(Exception e) {
//			
//			System.out.println(e);
//	
//		}
//	
//		return new ResponseEntity<>(prop, HttpStatus.OK);
	}


