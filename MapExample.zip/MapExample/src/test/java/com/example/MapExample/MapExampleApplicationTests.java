package com.example.MapExample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MapExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
