package com.Log_Ex.Log_Ex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages=("com.Log_Ex.Log_Ex"))
public class LogExApplication {

	public static void main(String[] args) {
		SpringApplication.run(LogExApplication.class, args);
	}

}
