package com.Log_Ex.Log_Ex.controller;

import java.util.Map;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


	@RestController
	@RequestMapping("/api/")
	
	public class Log_Excontroller {
		@RequestMapping(value = "testAPI", method = RequestMethod.GET)

		public ResponseEntity<?> testApi(@RequestParam Map<String, String> params) throws Exception {

			try {

				Logger log = LogManager.getLogger("Log_Ex");

				log.debug("testAPI started: " + params);
				log.info("testAPI started: " + params);
			} catch (Exception e) {

				e.printStackTrace();

			}

			return new ResponseEntity<>(params, HttpStatus.OK);
		}
	}

