package com.Log_Ex.Log_Ex;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogExApplicationTests {

	@Test
	void contextLoads() {
	}

}
